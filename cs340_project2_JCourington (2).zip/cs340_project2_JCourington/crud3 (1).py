from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter():
    def __init__(self,username,password):
        self.client=MongoClient('mongodb://%s:%s@localhost:54939/?authMechanism=DEFAULT&authSource=AAC'%('aacuser','password'))
        self.database=self.client['project']
       

    def create(self,data):
        if data is not None:
            self.database.animals.insert(data)
            return 'True'
        else:
            raise Exception('Nothing to save, because data parameter is empty')
            return 'False'
            
    def read(self,rule=None):
        if rule:
            data=self.database.animals.find(rule,{"_id":False})
        else:
            data=self.database.animals.find({},{"_id":False})
            return data
        
        a=AnimalShelter('mongo_user','password')
        
        animals=[
            {"name":"spot", "type":"dog"},
            {"name":"red", "type":"cat"},
            {"name":"fido","type":"dog"}
        ]
        
        for i in animals:
            a.create(i)
            
        dogs=a.read({"type":"dog"})
        for x in dogs:
            print(x)

    def update(self,data,updateRecord):
        self.database.animals.update(data,{"$set":updateRecord})
        a=AnimalShelter('mongo_user','password')
        a.read({'name':updateRecord})
        
                                             
        
    def delete(self,data):
       self.database.animals.remove({"name":data})
        
